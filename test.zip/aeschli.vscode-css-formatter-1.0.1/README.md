# VS Code CSS Formatting

This extension adds formatting to CSS.

## License
[MIT](https://github.com/aeschli/vscode-css-formatter/blob/master/LICENSE)